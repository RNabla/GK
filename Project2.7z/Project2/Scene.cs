﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Policy;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace Project2
{
    public class Scene
    {
        public ObservableCollection<MyPolygon> Polygons { get; set; }
            = new ObservableCollection<MyPolygon>();
        private readonly List<Line> PreviewLines = new List<Line>();

        private readonly List<Point> PreviewPoints = new List<Point>();
        public Animator Animator;
        public Image Background;
        public Canvas Canvas;
        public Label fpsCounter;
        public int maxVelocity = 100;
        public int minVelocity = 1;
        public MyLight MyLight = new MyLight();

        private Thread thread;
        public int velocityMax = 30;
        public int velocityMin = 10;
        public WriteableBitmap bitmap = new WriteableBitmap(1920, 1080, 96, 96, PixelFormats.Bgr32, null);
        public WriteableBitmap blankBitmap = new WriteableBitmap(1920, 1080, 96, 96, PixelFormats.Bgr32, null);
        public Scene(Canvas canvas, Image background)
        {
            Canvas = canvas;
            Animator = new Animator(Canvas, this);
            Background = background;
            Background.Source = bitmap;
            thread = new Thread(PaintAll);
            thread.Start();
            for (var i = 0; i < 1920; i++)
            {
                for (var j = 0; j < 1080; j++)
                    bgrd[i, j] = 255<<16;
            }
        }
        private int _stride;
        private int _size;
        private byte[] _pixels;
        private int _bumpStride;
        private int _bumpSize;
        private int _height;
        private int _width;
        private int _bumpHeight;
        private int _bumpWidth;
        private byte[] _bumpPixels;
        private Vector3D[,] _normalVectors;
        private readonly Vector3D N = new Vector3D(0,0,1);
        public void SetBumpMap(BitmapImage bitmap)
        {
            if (bitmap != null)
            {
                _bumpStride = bitmap.PixelWidth * 4;
                _bumpSize = bitmap.PixelHeight * _bumpStride;
                _bumpPixels = new byte[_bumpSize];
                bitmap.CopyPixels(_bumpPixels, _bumpStride, 0);
                _normalVectors = new Vector3D[bitmap.PixelWidth, bitmap.PixelHeight];
                Vector3D T = new Vector3D(1, 0, 0);
                Vector3D B = new Vector3D(0, 1, 0);
                for (int x = bitmap.PixelWidth - 1; x > 0; --x)
                {
                    for (int y = bitmap.PixelHeight - 1; y > 0; --y)
                    {
                      //  _normalVectors[x, y] = N + T * (GetHeight(x - 1, y) - GetHeight(x, y)) + B * (GetHeight(x, y - 1) - GetHeight(x, y));
                    }
                }
            }
        }
        public void SetBackground(BitmapImage bitmap)
        {
            if (bitmap != null)
            {
                _height = bitmap.PixelHeight;
                _width = bitmap.PixelWidth;
                _stride = bitmap.PixelWidth * 4;
                _size = bitmap.PixelHeight * _stride;
                _pixels = new byte[_size];
                bitmap.CopyPixels(_pixels, _stride, 0);
            }
        }


        private Tuple<byte, byte, byte> GetColorFromTexture(int x, int y)
        {
            x %= _width;
            y %= _height;
            var i = _stride * (y * _width + x);
            return new Tuple<byte, byte, byte>(_pixels[i], _pixels[i + 1], _pixels[i + 2]);
        }
        private Tuple<byte, byte, byte> GetColorFromHeight(int x, int y)
        {
            x %= _width;
            y %= _height;
            var i = _stride * (y * _width + x);
            return new Tuple<byte, byte, byte>(_pixels[i], _pixels[i + 1], _pixels[i + 2]);
        }




































        public void FinishThreadJob()
        {
            thread.Abort();
            thread.Join();
        }
        public WriteableBitmap HeightMap { get; set; }
        public WriteableBitmap NormalMap { get; set; }
        private WriteableBitmap _backgroundMap;
        public WriteableBitmap BackgroundMap
        {
            get => _backgroundMap;
            set
            {
                _backgroundMap = value;
                //var height = (int)_backgroundMap.Height;
                //var width = (int) _backgroundMap.Width;
                //var stride = _backgroundMap.BackBufferStride;
                //var buffer = new byte[stride * height];
                //_backgroundMap.CopyPixels(buffer, stride, 0);
                //for (var i = 0; i < width; i++)
                //{
                //    for (var j = 0; j < height; j++)
                //    {
                //        var index = j * stride + i * 4;
                //        bgrd[i, j] = transformbytestouint(buffer[index], buffer[index + 1], buffer[index+2],
                //            buffer[index + 3]);
                //    }
                //}
                //for (var i = width; i < 1920; i++)
                //{
                //    for (var j = height; j < 1080; j++)
                //    {
                //        bgrd[i, j] = bgrd[i / width, j / height];
                //    }
                //}
                //bitmap.Dispatcher.Invoke(() =>
                //{
                //    for (var i = 0;i<1920;i++)
                //    for (var j = 0; j < 1080; j++)
                //        DrawPixel(i, j);
                //    // Thread.Sleep(1000);
                //    bitmap.Lock();
                //    bitmap.AddDirtyRect(new Int32Rect(0, 0, 1920, 1080));
                //    bitmap.Unlock();
                //});
            }
        }

        public uint transformbytestouint(byte a, byte r, byte g, byte b)
        {
            return (uint) (a << 24 + r << 16 + g << 8 + b);
        }

        public uint[,] bgrd = new uint[1920,1080];
        public Color LightColor { get; set; }

        public string RandomPolygonCount
        {
            get => Animator.RandomPolygonsCount;
            set => Animator.RandomPolygonsCount = value;
        }

        public string Fps
        {
            get => Animator.Fps;
            set => Animator.Fps = value;
        }

        public string VelocityMax
        {
            get => $"{velocityMax}";
            set
            {
                if (int.TryParse(value, out var vMax) && vMax >= velocityMin && vMax <= maxVelocity)
                    velocityMax = vMax;
            }
        }

        public string VelocityMin
        {
            get => $"{velocityMin}";
            set
            {
                if (int.TryParse(value, out var vMin) && vMin <= velocityMax && vMin >= minVelocity)
                    velocityMin = vMin;
            }
        }

        public void PaintAll()
        {
            Thread.Sleep(1000);
            try
            {
                while (true)
                {
                    Animator.DoTick();
                    RedrawAll();
                    foreach (var randomPolygon in Animator.randomPolygons)
                    {
                        foreach (var userPolygon in Polygons)
                        {

                            var x = SutherlandHodgman.GetIntersectedPolygon(userPolygon, randomPolygon);
                            if (x.Length <= 2) continue;
                            var clippedPolygon = new MyPolygon(x, Canvas, this, 0);
                            FillPolygon(clippedPolygon);
                        }
                    }
                    bitmap.Dispatcher.Invoke(() =>
                    {
                        bitmap.Lock();
                        bitmap.AddDirtyRect(new Int32Rect(0, 0, 1920, 1080));
                        bitmap.Unlock();
                    });
                    Thread.Sleep(1000/60);

                }
            }
            catch (Exception exception)
            {
                return;
            }
        }

        public byte[] OneLine = new byte[1920 * 4];

        public void RedrawAll()
        {
            
            bitmap.Dispatcher.Invoke(() =>
            {
                bitmap.Lock();
                for (var i =0;i<1080;i++)
                    bitmap.WritePixels(new Int32Rect(0, i, 1920,1), OneLine, OneLine.Length, 0);
                bitmap.AddDirtyRect(new Int32Rect(0, 0, 1920, 1080));
                bitmap.Unlock();
                
            });
        }
        public Line AddLineToCanvas(Point p1, Point p2, Brush brush)
        {
            Line line = null;
            Canvas.Dispatcher.Invoke(() =>
            {
                line = new Line
                {
                    X1 = p1.X,
                    X2 = p2.X,
                    Y1 = p1.Y,
                    Y2 = p2.Y,
                    Visibility = Visibility.Visible,
                    Stroke = brush,
                    StrokeThickness = 1
                };
                Canvas.Children.Add(line);
                return line;
            });
            return line;
        }

        public void RemoveLineFromCanvas(Line line)
        {
              Canvas.Dispatcher.Invoke(() => Canvas.Children.Remove(line));

        }

        public void RemovePolygon(MyPolygon polygon)
        {
            Polygons.Remove(polygon);
        }

        public void TransformLines(IEnumerable<Line> lines, int dx)
        {
            foreach (var line in lines)
                line.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        line.X1 -= dx;
                        line.X2 -= dx;
                    }
                    catch
                    {
                    }
                });
        }

        public void AddPoint(Point point)
        {
            PreviewPoints.Add(point);
            if (PreviewPoints.Count >= 2)
            {
                var p1 = PreviewPoints[PreviewPoints.Count - 2];
                var p2 = PreviewPoints.Last();
                var line = new Line
                {
                    X1 = p1.X,
                    X2 = p2.X,
                    Y1 = p1.Y,
                    Y2 = p2.Y,
                    Fill = Brushes.DarkRed,
                    Visibility = Visibility.Visible,
                    Stroke = Brushes.Blue,
                    StrokeThickness = 1
                };
                PreviewLines.Add(line);
                Canvas.Children.Add(line);
            }
        }

        public void EndDrawingPolygon()
        {
            if (PreviewPoints.Count <= 2)
                goto end;
            var myPolygon = new MyPolygon(PreviewPoints, Canvas, this, new Random().Next(velocityMin, velocityMax));
            Polygons.Add(myPolygon);
            myPolygon.AddLinesToCanvas(Brushes.Green);
            end:
            PreviewLines.ForEach(l => Canvas.Children.Remove(l));
            PreviewLines.Clear();
            PreviewPoints.Clear();
        }

        public Queue<Tuple<Point, Point>> CreateET(MyPolygon polygon)
        {
            var buckets = new List<Tuple<Point, Point>>[1080];
            int n = polygon.Points.Count;
            var edges = new List<Tuple<Point, Point>>(n);
            for (int i = n - 1, j = 0; j < n; i = j, j++)
            {
                var p1 = polygon.Points[i];
                var p2 = polygon.Points[j];
                edges.Add(new Tuple<Point,Point>(p1,p2));
            }
            foreach (var edge in edges)
            {
                var minY = (int) Math.Min(edge.Item1.Y, edge.Item2.Y);
                var tuple = edge;
                if (edge.Item1.Y > edge.Item2.Y)
                    tuple = new Tuple<Point, Point>(edge.Item2, edge.Item1);
                if (buckets[minY] == null)
                    buckets[minY] = new List<Tuple<Point, Point>>();
                buckets[minY].Add(tuple);
            }
            var et = new Queue<Tuple<Point, Point>>();
            for (var i = 0; i < buckets.Length; i++)
            {
                if (buckets[i] == null) continue;
                foreach (var tuple in buckets[i])
                    et.Enqueue(tuple);
            }
            return et;
        }

        private int PeekY(Queue<Tuple<Point, Point>> et)
        {
            var element = et.FirstOrDefault();
            if (element == null) return -1;
            return (int) element.Item1.Y;
        }


        public void DrawLineBetweenPairs(List<EdgeStruct> aet, int y)
        {
            var first = default(EdgeStruct);
            var flag = false;
            foreach (var element in aet)
            {
                flag ^= true;
                if (flag)
                {
                    first = element;
                    continue;
                }
                var begin = Math.Min((int) first.Xmin,1920);
                var end = Math.Min((int) element.Xmin,1920);
                if (begin >= 1920) continue;
                begin = Math.Max(0, begin);
                end = Math.Max(0, end);
                //var clr = new byte[(end - begin) * 3];
                //for (var i = 0; i < clr.Length; i += 3)
                //    clr[i] = 255;
                //bitmap.WritePixels(new Int32Rect(begin,y,end-begin,1),clr,clr.Length,0 );
                for (var i = begin; i < end; i++)
                    DrawPixel(i, y);
             
            }
        }

        public void DrawPixel(int x, int y)
        {
            if (x < 0 || x >= 1920 || y < 0 || y >= 1080)
                return;
            //var color = new byte[] {(byte) (bgrd[x, y] >>24), (byte)(bgrd[x, y] >> 16) , (byte)(bgrd[x, y] >> 8) , (byte)(bgrd[x, y] >> 0) };
            //bitmap.WritePixels(new Int32Rect(x,y,1,1), color,color.Length,0);
            //unsafe
            //{
            //   // byte* p = (byte*)_bitmap.BackBuffer.ToPointer();


            //    // Get a pointer to the back buffer.
            //    int pBackBuffer = (int)bitmap.BackBuffer;

            //    // Find the address of the pixel to draw.
            //    pBackBuffer += y * bitmap.BackBufferStride;
            //    pBackBuffer += x * 4;

            //    // Assign the color data to the pixel.
            //    *((int*)pBackBuffer) = (int)bgrd[x, y];
            //}
            var hMap = new byte[4];
            HeightMap.CopyPixels(new Int32Rect(x, y, 1, 1), hMap, 4, 0);
            bitmap.WritePixels(new Int32Rect(x,y,1,1), hMap,hMap.Length,0);

        }


        public void FillPolygon(MyPolygon polygon)
        {
            bitmap.Dispatcher.Invoke(() =>
            {
                bitmap.Lock();
                var et = CreateET(polygon);
                var aet = new List<EdgeStruct>();
                var yMin = polygon.MinY;
                while (aet.Count + et.Count > 0 && yMin <= polygon.MaxY)
                {
                    while (PeekY(et) == yMin - 1)
                    {
                        var tuple = et.Dequeue();
                        var m = (tuple.Item2.X - tuple.Item1.X) / (tuple.Item2.Y - tuple.Item1.Y);
                        var edgeStruct = new EdgeStruct(tuple, m);
                        aet.Add(edgeStruct);
                    }
                    // posortuj liste aet wg x
                    aet.Sort();
                    // wypelnij pixele pomiedzy parami 
                    DrawLineBetweenPairs(aet, yMin);
                    // usuń z AET te elementy, dla których y=ymax
                    aet.RemoveAll(edgeStruct => edgeStruct.Ymax == yMin);
                    // zwieksz y o 1
                    yMin++;
                    // dla kazdej w AET uaktualnij x
                    foreach (var element in aet)
                        element.AddM();
                }
                bitmap.Unlock();
                
            });
        }

        public class EdgeStruct : IComparer<EdgeStruct>, IComparable<EdgeStruct>
        {
            public int Ymax;
            public double Xmin;
            public double M; // dx/dy

            public void AddM()
            {
                Xmin += M;
            }
            public EdgeStruct(Tuple<Point, Point> tuple, double m)
            {
                Ymax = (int)tuple.Item2.Y;
                Xmin = tuple.Item1.X;
                M = m;
            }

            public int Compare(EdgeStruct x, EdgeStruct y)
            {
                return x.Xmin.CompareTo(y.Xmin);
            }

            public int CompareTo(EdgeStruct other)
            {
                var xCompare = Xmin.CompareTo(other.Xmin);
                if (xCompare == 0)
                    return other.Ymax.CompareTo(Ymax);
                return xCompare;
            }
        }
    }

    public static class LinkedListExtensions
    {
        // stolenborrowed from stack
        public static void RemoveAll<T>(this LinkedList<T> linkedList,
            Func<T, bool> predicate)
        {
            for (var node = linkedList.First; node != null;)
            {
                var next = node.Next;
                if (predicate(node.Value))
                    linkedList.Remove(node);
                node = next;
            }
        }
    }

}