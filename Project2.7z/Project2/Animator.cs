﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace Project2
{
    public class Animator
    {
        private readonly object SyncRoot = new object();
        private readonly Random rng = new Random();
        public List<MyPolygon> randomPolygons = new List<MyPolygon>();
        private readonly Canvas Canvas;
        private readonly Scene Scene;
        public bool Run = true;

        public string RandomPolygonsCount
        {
            get => $"{_randomPolygonCount}";
            set
            {
                if (int.TryParse(value, out var randomPolygonCount) &&
                    (_randomPolygonCountMin <= randomPolygonCount && randomPolygonCount <= _randomPolygonCountMax))
                {
                    Interlocked.Exchange(ref _randomPolygonCount, randomPolygonCount);
                }
            }
        }

        private int _randomPolygonCount = 1;
        private int _randomPolygonCountMin = 0;
        private int _randomPolygonCountMax = 100;

        public Animator(Canvas canvas, Scene scene)
        {
            Canvas = canvas;
            Scene = scene;
            thread = new Thread(Animate);
           // thread.Start();
        }

        public void EndAnimation()
        {
            //Run = false;
            //thread.Abort();
            //thread.Join();
        }
        private DateTime lastTick = DateTime.Now;
        private DateTime now = DateTime.Now;
        public void DoTick()
        {
                now = DateTime.Now;
                var dt = now.Subtract(lastTick).TotalMilliseconds;
                Scene.fpsCounter.Dispatcher.Invoke(() =>
                {
                    Scene.fpsCounter.Content = $"FPS: {(int)(1000 / dt)}";
                });
                foreach (var polygon in randomPolygons)
                {
                    polygon.Transform();
                }
                randomPolygons.RemoveAll(polygon => polygon.MaxX <= 0);
                for (var i = randomPolygons.Count; i < _randomPolygonCount; i++)
                {
                    var poly = MyPolygon.GenerateRandomPolygon(1920, 1080, rng, Canvas, Scene,
                        Scene.velocityMin, Scene.velocityMax);
                    randomPolygons.Add(poly);
                }
                lastTick = DateTime.Now;
        }
        private readonly Thread thread;
        public void Animate()
        {
            Thread.Sleep(100);
            var lastTick = DateTime.Now;
            var now = DateTime.Now;
            var rng = new Random();
            try
            {
                while (Run)
                {
                    lock (SyncRoot)
                    {
                        now = DateTime.Now;
                        var dt = now.Subtract(lastTick).TotalMilliseconds;
                        Scene.fpsCounter.Dispatcher.Invoke(() =>
                        {
                            Scene.fpsCounter.Content = $"FPS: {(int) (1000 / dt)}";
                        });
                        foreach (var polygon in randomPolygons)
                        {
                            polygon.Transform();
                        }
                        randomPolygons.RemoveAll(polygon => polygon.MaxX <= 0);
                        for (var i = randomPolygons.Count; i < _randomPolygonCount; i++)
                        {
                            var poly = MyPolygon.GenerateRandomPolygon(1920, 1080, rng, Canvas, Scene,
                                Scene.velocityMin, Scene.velocityMax);
                            randomPolygons.Add(poly);
                            poly.AddLinesToCanvas(Brushes.DarkRed);                       
                        }
                        lastTick = DateTime.Now;
                        Thread.Sleep(1000/60);
                    }
                }
            }
            catch (Exception exception)
            {
                return;
            }
        }

        private int _fps;

        public string Fps
        {
            get => $"{_fps}";
            set
            {
                if (int.TryParse(value, out int v))
                {
                    _fps = v;
                }
            }
        }
    }
}
